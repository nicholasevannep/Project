$(document).ready(() => {
	var slideWidth = $('.slide').width();
	var isOpen = false;
	$('.nav-hp').hide();
	$('.burger').click(() => {
		$('.burger').toggleClass('change');
		if (!isOpen) {
			$('.nav-hp').show(300);
			isOpen = true;
		} else if (isOpen) {
			$('.nav-hp').hide(300);
			isOpen = false;
		}
	});

	$('.slide:last-child').prependTo('.slides');
	$('.prev').click(() => {
		$('.slides').animate(
			{
				left: +slideWidth
			},
			1000,
			function() {
				$('.slide:last-child').prependTo('.slides');
				$('.slides').css('left', '');
			}
		);
	});
	$('.next').click(() => {
		$('.slides').animate(
			{
				left: -slideWidth
			},
			1000,
			function() {
				$('.slide:first-child').appendTo('.slides');
				$('.slides').css('left', '');
			}
		);
	});
});
